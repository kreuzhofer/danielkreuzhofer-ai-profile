---
dokumenttyp: Interne Marktstudie
unternehmen: Lindner Werkzeugbau GmbH
abteilung: Strategie & Vertriebscontrolling
stand: 31. Januar 2026 (Datenbasis Q4 2025)
freigabe: K. Lindner (GF), R. Sommer (Leiter Vertrieb)
klassifikation: Vertraulich — nur interner Gebrauch
---

# Marktanalyse Profi-Handwerkzeug DACH 2025

**Stand: Q4 2025 — erstellt Januar 2026 für interne Strategieplanung 2026**

---

## 1. Marktdefinition

**Segment:** Profi-Handwerkzeug DACH (Deutschland, Österreich, Schweiz)

**Produktumfang:**
- Handgeführte Akku-Werkzeuge (Bohrer, Schrauber, Schleifer, Sägen, Multifunktion)
- Stationäre Profi-Werkzeuge im Handgeführt-Segment
- Mess- und Anreißwerkzeuge Profi-Klasse
- Werkzeug-Zubehör (Bits, Bohrer, Trennscheiben) im Profi-Bedarf

**Abnehmer-Segmente:**
- Handwerk (Bauhandwerk, Ausbaugewerbe, Schreiner, Elektro, SHK)
- Bauunternehmen / Generalunternehmer
- Industrie (Instandhaltung, Werkstatt, Fertigung)
- Sonstige (Kommunal, Vermieter, Profi-Handel)

**Vertriebskanäle:** Fachhandel (Eisenwarenhandel, Bau-Profi-Center), Direktvertrieb, Online-Profi-Plattformen (Contorion, Würth direkt). Privat-Endkunden / Baumärkte sind **nicht Teil dieser Marktdefinition**.

---

## 2. Marktgröße DACH

| Jahr | Marktvolumen DACH | YoY |
|---|---|---|
| 2023 | 4,98 Mrd. € | — |
| 2024 | 5,06 Mrd. € | +1,6 % |
| 2025 | 5,17 Mrd. € | +2,2 % |
| 2026 (Forecast) | 5,22 Mrd. € | +1,0 % (Konjunktur-Eintrübung Bau) |

**Methodik:** Triangulation aus drei Datenquellen — siehe Abschnitt 5.

**Strukturmerkmale 2025:**
- Deutschland: 71 % des DACH-Volumens (3,67 Mrd. €)
- Österreich: 11 % (0,57 Mrd. €)
- Schweiz: 18 % (0,93 Mrd. €) — überproportional zur Bevölkerung wegen höherer Profi-Werkzeug-Preisniveau und ausgeprägter Bau-Wirtschaft

---

## 3. Marktanteile Top-Anbieter DACH 2025 (Schätzung)

| Anbieter | Marktanteil DACH | Geschätzter DACH-Umsatz Profi-Handwerkzeug 2025 | Vertriebsmodell-Schwerpunkt |
|---|---|---|---|
| Hilti Group | 14,2 % | ~734 Mio. € | Direktvertrieb, Bau-Profi-Fokus |
| Bosch Power Tools (Professional) | 12,5 % | ~646 Mio. € | Fachhandel + Direkt, Akku-Plattform 18V |
| Würth-Gruppe | 9,8 % | ~507 Mio. € | Direktvertrieb / Außendienst, Multikanal |
| Makita | 7,1 % | ~367 Mio. € | Fachhandel, Akku LXT/XGT |
| Festool / TTS | 5,3 % | ~274 Mio. € | Fachhandel, Holz-Profi-Nische |
| **Top-5 Summe** | **48,9 %** | **~2,53 Mrd. €** | |
| Lindner Werkzeugbau | 0,37 % | ~19,1 Mio. € | Fachhandel + selektive Direktkunden |
| Sonstige (~120 Anbieter) | 50,7 % | ~2,62 Mrd. € | hochfragmentiert (Spezialisten + Importeure) |

**Hinweis:** Die Marktanteils-Schätzung basiert auf öffentlichen Konzernzahlen (Hilti, Würth, Bosch, Makita) anteilig auf DACH heruntergerechnet — multipliziert mit branchenüblichen DACH-Anteilen aus der FWI-Verbandsstatistik. Festool/TTS-Anteil aus Branchenumfrage Q4 2025 (n=83 Fachhändler).

---

## 4. Lindner-Marktanteil — Berechnungsgrundlage

**Methodik der eigenen Marktanteils-Schätzung:**

1. **Eigener DACH-Umsatz Profi-Handwerkzeug 2025 (vorläufig):** 19,12 Mio. €
   - Datenbasis: SAP-FI Auswertung, Vertriebsregionen DACH, Produkt-Kategorien laut interner Profi-Handwerkzeug-Definition
2. **DACH-Gesamtmarkt 2025:** 5,17 Mrd. € (siehe Abschnitt 2)
3. **Marktanteil = 19,12 / 5.170 = 0,37 %**

Anteilsentwicklung:
| Jahr | Lindner DACH-Umsatz | Marktanteil |
|---|---|---|
| 2023 | 17,8 Mio. € | 0,36 % |
| 2024 | 18,4 Mio. € | 0,36 % |
| 2025 | 19,1 Mio. € | 0,37 % |

**Strategische Einordnung:** Lindner ist im Long-Tail-Segment "Sonstige" positioniert, mit seit 2023 leicht steigendem Anteil bei stabilem Mengen-Mix. Eine Marktanteils-Verdopplung auf 0,75 % bedeutet Verdrängung von rund 20 Mio. €/Jahr aus dem Long-Tail oder von kleineren Top-50-Anbietern — realistisch nur über Spezialisierung oder Akquise.

---

## 5. Methodik & Datenquellen

### 5.1 Externe Quellen
- **FWI Fachverband Werkzeugindustrie e.V.** — Jahresstatistik 2025 (Lindner Mitgliedszugang)
- **GfK Marktdaten Werkzeug DACH** — Punktdaten Q4 2025 (Lizenzbasis, Marketing-Budget)
- **Geschäftsberichte / Pressemitteilungen** der Top-5-Wettbewerber 2024 + 2025 H1
- **Statista Industry Outlook** „Werkzeuge & Maschinen Deutschland" 2025
- **Eigene Fachhändlerbefragung** Q4 2025 (n=83 Profi-Fachhändler in DACH; Schwerpunkt regionale Marktanteile)

### 5.2 Triangulation
Für Marktgröße und Wettbewerber-Anteile werden drei Schätzpfade gerechnet und mit der Median-Methode konsolidiert:

1. **Top-Down:** Statista/FWI Marktgröße × Wettbewerber-Konzernanteil (DACH-Korrektur über Geschäftsbericht-Geo-Sektion)
2. **Bottom-Up:** Eigene Fachhändlerbefragung — gemeldete Lieferanten-Anteile am Profi-Sortiment, hochgerechnet
3. **Cross-Check:** GfK-Punktdaten (limitiert auf Akku-Werkzeuge) — Plausibilisierung der Top-5-Reihenfolge

Abweichungen zwischen den drei Pfaden < 1,5 Prozentpunkten je Wettbewerber für Top-5; entsprechend hohe Konfidenz.

### 5.3 Limitationen
- **Festool/TTS** veröffentlicht keine Konzernzahlen → Schätzung allein aus Bottom-Up + Cross-Check, ohne Top-Down-Anker. Konfidenz-Intervall: ±1,5 Prozentpunkte.
- **Long-Tail "Sonstige"** ist hoch fragmentiert; eine Detail-Aufgliederung der ~120 Wettbewerber ist mit der vorhandenen Datenbasis nicht möglich.
- **Schweizer Markt** wird in Statista nur als Teil "EU+CH" geführt — Schweizer Anteil aus FWI + Cross-Check Schweizer Fachhandelsverband.

---

## 6. Marktanteils-Veränderungen 2024 → 2025 (Beobachtungen)

| Anbieter | 2024 → 2025 | Treiber |
|---|---|---|
| Hilti | leicht rückläufig | Direktvertriebs-Modell stagniert in Hochbau, Konzern-Wechselkurs (CHF) |
| Bosch Professional | steigend | Akku-Plattform 18V Marktdurchdringung Handwerk |
| Würth | stabil | konstantes Außendienst-Wachstum |
| Makita | leicht steigend | XGT 40V im Bauhandwerk angenommen |
| Festool | stabil | Spezialist-Position gefestigt, kein Volumen-Wachstum |
| Lindner | leicht steigend (+0,01 pp) | Volumen-Wachstum 2024–2025 mit Markt mitgewachsen |

---

## 7. Konjunktur-Hinweise für 2026

**Bauhandwerk DACH:** Auftragsbestände lt. ZDB November 2025: −7,1 % YoY (Wohnungsbau −12,4 %, Wirtschaftsbau −3,1 %). Stark erwartet wird Eintrübung im Profi-Werkzeug-Bedarf der Bau-Branche **ab Q1 2026**.

**Handwerk allgemein:** Auftragslage stabil, Zahlungsfristen verlängert. Produkt-Nachfrage Akku-Werkzeuge konstant.

**Industrie-Instandhaltung:** Wachstumssegment 2025; CapEx-Verschiebungen aus Bau in Industrie-MRO erwartet.

**Erwarteter Markt-YoY 2026:** +1,0 % (gegenüber +2,2 % 2025) — primär getrieben durch Bau-Schwäche; Handwerk und Industrie kompensieren teilweise.

---

## 8. Quellenliste (extern)

- FWI Fachverband Werkzeugindustrie e.V., Jahresstatistik 2025 (Mitgliederbereich)
- GfK „Werkzeug-Markt DACH" Punktdaten Q4 2025, Lizenz Lindner Marketing
- Hilti Group Annual Report 2024 + Pressemitteilung Umsatz 2025
- Würth-Gruppe Pressemitteilung 15.01.2026 „Würth Group reports record sales in 2025"
- Bosch Annual Report 2024, Bosch Today 2025
- Makita FYE2025 Operating Results
- TTS / Festool Nachhaltigkeitsbericht 2023 (letzter veröffentlichter)
- Statista Industry Outlook „Werkzeuge & Maschinen Deutschland" 2025
- ZDB Zentralverband Deutsches Baugewerbe, Konjunkturbericht November 2025

---

*Dokument intern erstellt durch Strategie & Vertriebscontrolling Lindner Werkzeugbau GmbH. Klassifikation „Vertraulich — nur interner Gebrauch". Nicht zur Weitergabe an Dritte ohne Freigabe der Geschäftsführung. Disclaimer: Sämtliche Marktanteils-Angaben sind Schätzungen auf Basis der unter 5.1 genannten Quellen; Methodik in 5.2 beschrieben. Für externe Verwendung ist Rücksprache mit der GF erforderlich.*
