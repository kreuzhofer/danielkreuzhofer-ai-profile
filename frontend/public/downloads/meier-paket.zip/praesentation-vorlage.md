# Quartalspräsentation Beirat — Lindner Werkzeugbau GmbH

> Diese Markdown-Datei ist die Inhalts-Vorlage für die "alte" Präsentation (Stand: nach Q4 2025).
> Daraus erzeugst du die `.pptx` für die Demo. Die KI bekommt entweder diese `.md` oder die daraus generierte `.pptx`.
> Die KI soll diese Folien auf **Q1 2026** aktualisieren und zusätzlich Konkurrenzanalyse + Stagnations-Folie ergänzen.

---

## Folie 1 — Titel

**Quartalsbericht Q4 2025**
Lindner Werkzeugbau GmbH
Beiratssitzung — 12. Januar 2026

---

## Folie 2 — Geschäftsverlauf 2025 im Überblick

- Gesamtumsatz 2025: **83,78 Mio. €** (+6,1 % YoY)
- EBIT-Marge 2025: **9,55 %** (Vorjahr: 9,6 %)
- Neukunden 2025 gesamt: **423**
- Marktanteil DACH Profi-Handwerkzeug: **0,38 %** (stabil)

---

## Folie 3 — Quartalsumsätze 2024 vs. 2025

| Quartal | 2024 | 2025 | YoY |
|---|---|---|---|
| Q1 | 17,85 Mio. € | 18,90 Mio. € | +5,9 % |
| Q2 | 19,20 Mio. € | 20,45 Mio. € | +6,5 % |
| Q3 | 20,10 Mio. € | 21,28 Mio. € | +5,9 % |
| Q4 | 22,40 Mio. € | 23,15 Mio. € | +3,3 % |

*Hinweis: Q4-Wachstum hat sich abgeschwächt — Beobachtungspunkt für 2026.*

---

## Folie 4 — Kundenstruktur

- Bestandskunden Umsatz 2025: **75,95 Mio. €** (90,7 % Anteil)
- Neukunden Umsatz 2025: **7,83 Mio. €** (9,3 % Anteil)
- Top-Branchen: Handwerk (54 %), Bau (28 %), Industrie (13 %), Sonstige (5 %)

---

## Folie 5 — Vertrieb und Mitarbeiter

- Vertriebsmitarbeiter Stand Q4 2025: **37**
- Aufstockung gegenüber Q1 2024: +5 Mitarbeiter
- Außendienst-Quote: 73 % der Vertriebsmannschaft

---

## Folie 6 — Ausblick 2026

- Erwartetes Wachstum 2026: **+5 % YoY** (Plan)
- Investitionsschwerpunkte: Produktentwicklung Akku-Linie, Digitalisierung Vertriebs-Backoffice
- Risiko-Hinweise: Materialpreise, Wettbewerbsdruck im Profi-Segment

---

## Folie 7 — Fragen an den Beirat

- Investitionsfreigabe für neue Akku-Plattform (5,2 Mio. € über 2 Jahre)
- Empfehlung Beirat zu Markterweiterung Österreich/Schweiz

---

*Stand der alten Präsentation: 12. Januar 2026 — VOR Q1 2026 Zahlen.*
