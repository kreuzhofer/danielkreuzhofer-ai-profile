# Demo-Prompt für die Live-Aufnahme

> Dieser Prompt geht 1:1 in die KI. Fünf Anlagen vorher hochladen / verlinken:
> - `chef-email.md`
> - `Quartalsbericht-Q4-2025-Lindner-Werkzeugbau.pptx`
> - `geschaeftszahlen.csv`
> - `interne-marktstudie-dach-2025.md` *(Meiers eigener Beitrag — interne Marktstudie)*
> - `branchenmix-q1-2026-controlling.csv` *(Meiers eigener Beitrag — Controlling-Auswertung)*

---

## Prompt

Hi, ich brauche Hilfe bei einer Aufgabe von meinem Chef. Anbei findest Du:

**Vom Chef:**
1. **Die E-Mail vom Chef** mit den Änderungswünschen (`chef-email.md`)
2. **Die aktuelle Beirats-Präsentation** mit Stand Q4 2025 (`Quartalsbericht-Q4-2025-Lindner-Werkzeugbau.pptx`)
3. **Die aktuellen Geschäftszahlen** inklusive Q1 2026 (`geschaeftszahlen.csv`)

**Aus unseren internen Reports** (für die Markt- und Branchen-Einordnung):
4. **Unsere interne Marktstudie DACH** (Stand Q4 2025) (`interne-marktstudie-dach-2025.md`) — enthält Marktgröße DACH, Wettbewerber-Schätzungen und Methodik unserer Marktanteils-Berechnung
5. **Branchenmix Q1 2026 aus dem Controlling** (`branchenmix-q1-2026-controlling.csv`) — quartalsweise Aufteilung Handwerk / Bau / Industrie / Sonstige

Nutze die internen Reports, wo extern keine belastbaren Daten verfügbar sind (z. B. DACH-Marktanteile, Branchen-Aufgliederung). Kennzeichne klar, was aus internen Quellen stammt vs. aus öffentlichen Quellen.

Bitte überarbeite die Präsentation gemäß den Aufgaben in der Chef-E-Mail. Vier Sachen, die mir wichtig sind:

**Style-Treue zum Original (kritisch).**
Die überarbeitete Präsentation muss visuell vom Original ununterscheidbar sein. Das ist eine Beiratsvorlage — Style-Abweichungen werden in der Sitzung sofort bemerkt und lenken vom Inhalt ab.

- **Vor jeder Folien-Erstellung:** Extrahiere die exakten Farb-Codes (Hex/RGB), Schriftarten, Schriftgrößen, Master-Layouts und Akzent-Elemente aus der Original-`.pptx` (Folien 1–7).
- **Für überarbeitete Folien:** Gleiche Farb-Palette, gleiche Schriftarten, gleiche Layout-Grundstruktur wie die jeweilige Original-Folie. Keine neuen Akzentfarben (besonders kein abweichendes Orange/Rot/Grün), keine alternativen Schriftarten.
- **Für neu eingefügte Folien (z. B. Konkurrenzanalyse, Stagnations-Risiko):** Konsultiere die nächste vergleichbare Vorlagen-Folie (Tabelle → Folie 3, Karten/KPIs → Folien 2/4) und übernimm deren Stil 1:1.
- **Charts:** Identische Farb-Logik wie bestehende Charts in der Vorlage. Wenn die Vorlage keine Charts hat: dezent, in den Corporate-Farben, ohne Schmuck-Effekte.
- **Im Verifikationsbericht:** Liste die extrahierten Farb-Codes und Schriftarten der Vorlage und bestätige, dass sie in den neuen Folien 1:1 übernommen wurden. Falls Abweichungen unvermeidbar waren, explizit benennen und begründen.

**Quellen-Pflicht für die Konkurrenzanalyse.**
Jede Aussage und jede Zahl mit Quelle belegen (URL zu Geschäftsbericht, Pressemitteilung, Marktanalyse). Wenn keine belastbare öffentliche Quelle existiert, das explizit kennzeichnen — keine Schätzungen als Fakten ausgeben.

**Ehrlich schreiben.**
Keine Schönfärberei. Wenn die Daten unangenehme Befunde zeigen, klar benennen.

**Selbst-Verifikation, bevor Du abgibst.**
Geh kritisch über alle Folien:
- Stimmen die Zahlen mit der CSV?
- Sind alle Quellen-URLs echte, klickbare Links?
- Aussagen, die plausibel klingen aber nicht belegt sind, mit "⚠️ NICHT BELEGT" markieren
- Halluzinationen korrigieren oder kenntlich machen
- **Style-Konsistenz visuell prüfen:** Vergleiche jede neue/überarbeitete Folie mit der Original-Vorlage. Gleiche Akzentfarbe? Gleiche Schriftart? Gleiches Layout-Raster? Falls eine Folie visuell aus der Reihe tanzt, neu rendern

## Was Du am Ende lieferst

1. Die überarbeitete Präsentation (als Markdown oder direkt als `.pptx`)
2. Die Quellenliste für die Konkurrenzanalyse
3. Einen kurzen Verifikations-Bericht: was wurde geprüft, was bleibt unsicher
4. **Einen Antwort-Entwurf an den Chef** — kurze E-Mail (5–10 Zeilen), die zusammenfasst:
   - Welche Folien wurden geändert oder ergänzt
   - Welche zentralen Befunde aus den Q1-Zahlen und der Konkurrenzanalyse hervorgehen
   - Was im Verifikations-Bericht offen geblieben ist und vor der Beiratssitzung noch geprüft werden sollte

Tonalität sachlich, keine Verkäufersprache. Schreib so, wie Du sie wirklich Montag früh um 7:30 Uhr abschicken würdest.

---

## Hinweise für die Aufnahme

- Während die KI arbeitet, **live kommentieren**, was passiert — nicht stumm warten.
- Wenn die KI eine Frage stellt: ruhig im Video lassen, das ist ehrlich (kein Magic-Moment-Theater).
- Verifikation am Ende **explizit** zeigen: 2–3 Quellen-Links anklicken, kurz auf der Quelle nachschauen, dann Cut zurück.
- Wenn die Demo halluziniert: nicht verstecken, sondern als Lehr-Moment einbauen ("Genau das meine ich mit verifizieren").
- Den Antwort-Entwurf an den Chef am Ende kurz einblenden — zeigt, dass der Agent nicht nur Folien baut, sondern auch das Denken dahinter strukturiert.
