**Von:** Klaus Lindner <k.lindner@lindner-werkzeugbau.de>
**An:** Andreas Meier <a.meier@lindner-werkzeugbau.de>
**Datum:** Freitag, 17. April 2026, 16:47 Uhr
**Betreff:** Vorstandspräsentation Montag — bitte nochmal überarbeiten

Lieber Herr Meier,

der Beirat tagt am Montag um 9 Uhr. Ich brauche bis Montag früh 8 Uhr eine überarbeitete Version unserer Quartals-Präsentation. Die alte Fassung haben Sie ja noch.

Was ich brauche:

1. **Aktuelle Zahlen Q1 2026 einarbeiten.** Die Werte stehen in der CSV, die ich Ihnen letzte Woche geschickt habe. Bitte alle Zahlen auf Q1 2026 aktualisieren — Umsatz, Wachstum, Marktanteil DACH, alles.

2. **Konkurrenzanalyse Top 5.** Der Beirat hat letztes Mal gefragt, wo wir gegenüber dem Wettbewerb stehen. Bitte eine zusätzliche Folie (oder zwei) mit den fünf wichtigsten Konkurrenten im Profi-Handwerkzeug-Markt DACH: **Hilti, Würth, Bosch Professional, Festool, Makita**. Marktpositionierung, Stärken, Schwächen, ungefährer Marktanteil. Mir reicht eine grobe Einordnung, aber bitte mit Quellen — nicht nur Bauchgefühl.

3. **Eine Folie zu unserem Q1-Stagnations-Risiko.** Sie sehen es ja in den Zahlen: Q1 wächst quasi nicht mehr. Der Beirat wird fragen, woran das liegt und was wir dagegen tun. Bitte eine ehrliche Einordnung — keine Schönfärberei, das fliegt uns sonst um die Ohren.

Sie wissen ja, welche internen Reports wir im Haus haben — ziehen Sie heran, was Sie für die Konkurrenz- und Markt-Einordnung brauchen.

Sie machen das schon. Wenn Sie Fragen haben, ich bin Sonntagabend kurz erreichbar.

Schönes Wochenende,

Klaus Lindner
Geschäftsführer
Lindner Werkzeugbau GmbH
